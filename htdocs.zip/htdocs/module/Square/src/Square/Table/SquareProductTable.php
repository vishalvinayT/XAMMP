<?php

namespace Square\Table;

use Zend\Db\TableGateway\TableGateway;

class SquareProductTable extends TableGateway
{

    const NAME = 'bs_squares_products';

}