<?php

return array(

    'Today' => 'Aujourd\'hui',
    'Date' => 'Date',
    'Time' => 'Heure',
    'Show' => 'Voir',

    'To book %s, %splease register first%s' => 'Pour réserver les %s, %sveuillez vous enregistrer svp%s',
    'or simply %s login here' => 'ou simplement %s Connectez-vous ici',

    'Email address' => 'Adresse E-Mail',
    'Email' => 'E-Mail',
    'Phone' => 'Tel.',
    'Password' => 'Mot de passe',
    'Login' => 'Connexion',
    'Logout' => 'Déconnexion',

    'New password' => 'Nouveau mot de passe',

    'Get additional %shelp and information%s' => 'Obtenir %sune aide ou des Infos supplémentaires%s',

    'Online as %s' => 'Connecté en %s',

    'Administration' => 'Administration',

    'My bookings' => 'Mes Réservations',
    'My account' => 'Mon Compte',

);
