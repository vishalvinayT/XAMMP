<?php

return array(

    'System status' => 'Status du System',
    'Maintenance' => 'Maintenance',

    'Help' => 'Aide',

    'We are currently working on this page.' => 'Nous travaillons en ce moment sur cette page.',

    'The system is currently not available' => 'Le système est temporairement indisponible',
    'System maintenance underway' => 'En travaux',
    'We are back as fast as we can. Promised!' => 'Bientôt de retour...',

    'The system is available' => 'Le système fonctionne',

);