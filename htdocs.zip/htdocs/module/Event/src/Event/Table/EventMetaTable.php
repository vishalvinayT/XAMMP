<?php

namespace Event\Table;

use Zend\Db\TableGateway\TableGateway;

class EventMetaTable extends TableGateway
{

    const NAME = 'bs_events_meta';

}